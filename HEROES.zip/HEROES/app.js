// Require de Express
const express = require("express");

let rutaHeroes = require('./Routes/heroe.js');
let rutaMain = require('./Routes/main.js');

// Ejecución de Express
const app = express();

// Levantando el Servidor en el puerto 3030
app.listen(3030, () => console.log('Server running in 3030 port'));


app.use("/heroes", rutaHeroes);
app.use('/', rutaMain);



