// Require de FS
const fs = require("fs");

// Leyendo y parseando (en array) el contenido de heroes.json !json a objeto!
const heroes = JSON.parse(fs.readFileSync(__dirname + '/data/heroes.json', 'utf-8'));// __dirname te trae todo el directorio completo


let heroesController = 
{
    listar: function(req,res)
    { 
        res.send(heroes);
    },
    crear: function(){},
    detalle: function(req,res)
        {
        // Acá lo primero será encontrar al héroe que corresponda
        let heroe = heroes.find(x => x.id == req.params.id);
        if(heroe)
        {
            res.send(`Hola, mi nombre es ${heroe.nombre} y soy ${heroe.profesion}`);//utilizar el acento grave `
        }
        else 
        {
            res.send('No se encontro a ese heroe');
        }
        
        // Si se encuentra al héroe se envía el nombre y su profesión
        // Si NO se encuentra se envía el mensaje de no encontrado
    },
    biografia: function(req,res) 
    {
        // Acá lo primero será encontrar al héroe que corresponda
        let heroe = heroes.find(x => x.id == req.params.id);
        if(heroe)
        {
            if(req.params.ok!= undefined && req.params.ok =='ok')
            {
                res.send(` ${heroe.nombre}: ${heroe.resenia}`);//utilizar el acento grave `
            }
            else
            {
                res.send(`${heroe.nombre}: "lo lamento que no desees saber mas de mi :("`)
            }
        }
        else 
        {
            res.send('No encontramos un heroe para mostrarte su biografia');
        }
    
        // Si NO se encuentra al héroe se envía un mensaje
        // Si se encuentra al héroe:
            // Se pregunta si vino el parámetro Y el valor esperado y se envía la información
            // Si nó vino el parámetro se envía el mensaje de error
        
    },
}

module.exports = heroesController;