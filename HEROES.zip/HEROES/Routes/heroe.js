const express= require('express');
let router = express.Router();
let heroesControllers= require("../Controllers/heroesController.js");

// Ruta /heroes ➝ se envía todo el array y Express lo parsea para el browser como JSON :D
router.get('/', heroesControllers.listar);


// Ruta /heroes/n ➝ se envía el nombre y profesión del héroe solicitado
router.get('/detalle/:id',heroesControllers.detalle );


// Ruta /heroes/n/bio ➝ se envía la bio del héroe solicitado
router.get('/:id/bio/:ok?', heroesControllers.biografia);

module.exports = router;