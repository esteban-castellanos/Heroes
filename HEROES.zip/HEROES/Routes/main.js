const express= require('express');
let router = express.Router();
let mainControllers = require("../Controllers/mainControllers.js");


// Ruta Raíz / ➝ Home
router.get('/', mainControllers.home );

// Ruta Créditos
router.get('/creditos', mainControllers.creditos);

// Ruta... ¿Pára qué sirve esto?
router.get('*', mainControllers.errores);




module.exports = router